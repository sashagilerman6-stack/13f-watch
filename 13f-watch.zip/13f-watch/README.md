# 13F Watch

A small site that tracks what major hedge funds are holding, pulled from SEC EDGAR
13F-HR filings. Auto-updates itself daily via a scheduled GitHub Action (13F filings
themselves only change quarterly, but the site checks daily so it never lags more
than a day behind a new filing).

## How it works
- `fetch_13f.py` — pulls each fund's latest 13F-HR filing from SEC EDGAR, parses the
  top 10 holdings, and writes `data.json`. Runs server-side, so there's no browser
  CORS restriction (that's what broke the in-chat version of this).
- `.github/workflows/update.yml` — runs the script daily and commits `data.json` if
  it changed.
- `index.html` — static page that reads `data.json` and renders it. This is the file
  GitHub Pages serves.

## Deploy it (5 minutes)

1. **Create a new GitHub repo** (public or private — Pages works either way on a
   free personal account, though private repos need GitHub Pro for Pages).
2. **Upload these four files/folders**, keeping the folder structure:
   ```
   fetch_13f.py
   data.json
   index.html
   .github/workflows/update.yml
   ```
3. **Edit `fetch_13f.py`**: replace `CONTACT_EMAIL = "your-email@example.com"` with
   a real contact email. SEC asks automated tools to self-identify this way — it's
   not optional, but it's just a courtesy header, not an API key.
4. **Enable GitHub Pages**: repo Settings → Pages → Source: "Deploy from a branch" →
   Branch: `main`, folder `/ (root)` → Save. GitHub gives you a URL like
   `https://yourusername.github.io/13f-watch/`.
5. **Enable Actions** if prompted (Settings → Actions → Allow all actions).
6. **Run it once manually** to confirm it works: Actions tab → "Update 13F Data" →
   "Run workflow". Check the logs — you should see `OK: <fund name>` for each fund.

That's it. From here the Action runs daily on its own, commits fresh `data.json` when
a fund's filing changes, and the live site picks it up automatically (no rebuild step
needed — it's just a fetch on page load).

## Customizing
- **Add/remove funds**: edit the `FUNDS` list at the top of `fetch_13f.py` with the
  manager's name and CIK (look one up at
  `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&company=<name>&type=13F-HR`).
- **Change how often it checks**: edit the `cron` line in `update.yml`
  (uses standard cron syntax, in UTC).
- **Change how many holdings per fund**: edit `TOP_N` in `fetch_13f.py`.

## Limitations (inherent to 13F data, not this tool)
- Quarterly disclosure only, filed up to 45 days after quarter-end — there is no
  live feed of hedge fund trades anywhere, from any provider.
- No exact trade price or trade date — the SEC doesn't require funds to disclose
  that. "Added/Reduced" values are the dollar change between quarterly filings.
- US long equity positions only — no shorts, no international holdings, and options
  positions (common at multi-strategy funds like Citadel and Millennium) can distort
  the "top holdings by value" ranking.
